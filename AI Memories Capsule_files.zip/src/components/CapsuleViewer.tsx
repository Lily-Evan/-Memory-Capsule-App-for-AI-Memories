import  { ArrowLeft, Calendar, Gift, Zap, FileText, Camera, Music } from 'lucide-react';
import { Capsule } from '../types';

interface CapsuleViewerProps {
  capsule: Capsule;
  onClose: () => void;
}

const CapsuleViewer = ({ capsule, onClose }: CapsuleViewerProps) => {
  const getMemoryIcon = (type: string) => {
    switch (type) {
      case 'text': return <FileText className="w-5 h-5" />;
      case 'photo': return <Camera className="w-5 h-5" />;
      case 'audio': return <Music className="w-5 h-5" />;
      default: return <FileText className="w-5 h-5" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-lg p-8">
        <div className="flex items-center space-x-4 mb-6">
          <button
            onClick={onClose}
            className="flex items-center space-x-2 text-gray-600 hover:text-purple-600 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back to Capsules</span>
          </button>
        </div>

        <div className="text-center mb-8">
          <div className="w-20 h-20 bg-gradient-to-br from-purple-400 to-indigo-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <Zap className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">{capsule.title}</h1>
          <p className="text-gray-600 mb-4">{capsule.description}</p>
          
          <div className="flex items-center justify-center space-x-6 text-sm text-gray-500">
            <div className="flex items-center space-x-1">
              <Calendar className="w-4 h-4" />
              <span>Opened on {new Date(capsule.openDate).toLocaleDateString()}</span>
            </div>
            {capsule.giftRecipient && (
              <div className="flex items-center space-x-1">
                <Gift className="w-4 h-4" />
                <span>Gift for {capsule.giftRecipient}</span>
              </div>
            )}
          </div>
        </div>

        {capsule.aiNarrative && (
          <div className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-lg p-6 mb-8">
            <h3 className="text-lg font-semibold text-gray-900 mb-3 flex items-center">
              <Zap className="w-5 h-5 text-purple-600 mr-2" />
              AI-Generated Story
            </h3>
            <p className="text-gray-700 leading-relaxed">{capsule.aiNarrative}</p>
          </div>
        )}

        <div>
          <h3 className="text-xl font-semibold text-gray-900 mb-6">Your Memories</h3>
          <div className="grid gap-6">
            {capsule.memories.map((memory) => (
              <div key={memory.id} className="bg-gray-50 rounded-lg p-6">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 p-2 bg-white rounded-lg">
                    {getMemoryIcon(memory.type)}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-2">{memory.title}</h4>
                    {memory.type === 'photo' && memory.content.startsWith('http') ? (
                      <img
                        src={memory.content}
                        alt={memory.title}
                        className="w-full max-w-md rounded-lg mb-2"
                      />
                    ) : (
                      <p className="text-gray-700 whitespace-pre-wrap">{memory.content}</p>
                    )}
                    <span className="inline-block mt-2 px-2 py-1 bg-purple-100 text-purple-700 text-xs rounded">
                      {memory.type}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CapsuleViewer;
 