import  { useState } from 'react';
import { Calendar, Clock, Gift, Eye, Trash, Zap } from 'lucide-react';
import { Capsule } from '../types';
import CapsuleViewer from './CapsuleViewer';

interface CapsuleListProps {
  capsules: Capsule[];
  setCapsules: (capsules: Capsule[]) => void;
}

const CapsuleList = ({ capsules, setCapsules }: CapsuleListProps) => {
  const [selectedCapsule, setSelectedCapsule] = useState<Capsule | null>(null);

  const canOpenCapsule = (capsule: Capsule) => {
    return new Date(capsule.openDate) <= new Date();
  };

  const openCapsule = async (capsule: Capsule) => {
    if (!canOpenCapsule(capsule) && !capsule.isOpened) return;

    if (!capsule.aiNarrative) {
      try {
        const response = await fetch('https://hooks.jdoodle.net?url=https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            model: 'gpt-3.5-turbo',
            messages: [{
              role: 'user',
              content: `Create a beautiful, emotional narrative from these memories: ${JSON.stringify(capsule.memories.map(m => ({ title: m.title, content: m.content })))}`
            }],
            max_tokens: 500
          })
        });

        const data = await response.json();
        capsule.aiNarrative = data.choices?.[0]?.message?.content || 'Your memories are precious treasures from the past.';
      } catch (error) {
        capsule.aiNarrative = 'Your memories are precious treasures, each one a unique moment in time that shaped who you are today.';
      }
    }

    const updatedCapsule = { ...capsule, isOpened: true };
    setCapsules(capsules.map(c => c.id === capsule.id ? updatedCapsule : c));
    setSelectedCapsule(updatedCapsule);
  };

  const deleteCapsule = (id: string) => {
    setCapsules(capsules.filter(c => c.id !== id));
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (selectedCapsule) {
    return <CapsuleViewer capsule={selectedCapsule} onClose={() => setSelectedCapsule(null)} />;
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-lg p-8">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-gray-900">My Memory Capsules</h2>
          <div className="text-sm text-gray-600">
            {capsules.length} capsule{capsules.length !== 1 ? 's' : ''}
          </div>
        </div>

        {capsules.length === 0 ? (
          <div className="text-center py-12">
            <Clock className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No capsules yet</h3>
            <p className="text-gray-600">Create your first memory capsule to get started</p>
          </div>
        ) : (
          <div className="grid gap-6">
            {capsules.map((capsule) => {
              const isOpenable = canOpenCapsule(capsule);
              const daysUntilOpen = Math.ceil((new Date(capsule.openDate).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));

              return (
                <div key={capsule.id} className="border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-gray-900 mb-1">{capsule.title}</h3>
                      <p className="text-gray-600 mb-3">{capsule.description}</p>
                      
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <div className="flex items-center space-x-1">
                          <Calendar className="w-4 h-4" />
                          <span>Opens {formatDate(capsule.openDate)}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <Clock className="w-4 h-4" />
                          <span>{capsule.memories.length} memories</span>
                        </div>
                        {capsule.giftRecipient && (
                          <div className="flex items-center space-x-1">
                            <Gift className="w-4 h-4" />
                            <span>For {capsule.giftRecipient}</span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      {capsule.isOpened ? (
                        <span className="flex items-center space-x-1 px-3 py-1 bg-green-100 text-green-700 rounded-full text-sm">
                          <Zap className="w-4 h-4" />
                          <span>Opened</span>
                        </span>
                      ) : isOpenable ? (
                        <span className="flex items-center space-x-1 px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-sm">
                          <Clock className="w-4 h-4" />
                          <span>Ready</span>
                        </span>
                      ) : (
                        <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm">
                          {daysUntilOpen} days left
                        </span>
                      )}

                      <button
                        onClick={() => openCapsule(capsule)}
                        disabled={!isOpenable && !capsule.isOpened}
                        className="flex items-center space-x-1 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
                      >
                        <Eye className="w-4 h-4" />
                        <span>Open</span>
                      </button>

                      <button
                        onClick={() => deleteCapsule(capsule.id)}
                        className="p-2 text-gray-400 hover:text-red-600 transition-colors"
                      >
                        <Trash className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};

export default CapsuleList;
 