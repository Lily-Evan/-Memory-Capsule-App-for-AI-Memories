export  interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'premium';
}

export interface Memory {
  id: string;
  type: 'text' | 'audio' | 'photo';
  content: string;
  title: string;
}

export interface Capsule {
  id: string;
  title: string;
  description: string;
  memories: Memory[];
  openDate: string;
  isOpened: boolean;
  aiNarrative?: string;
  createdAt: string;
  giftRecipient?: string;
}
 