import  { useState } from 'react';
import { Plus, Calendar, Gift, FileText, Camera, Music } from 'lucide-react';
import { Capsule, Memory } from '../types';

interface CreateCapsuleProps {
  onCreateCapsule: (capsule: Capsule) => void;
}

const CreateCapsule = ({ onCreateCapsule }: CreateCapsuleProps) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [openDate, setOpenDate] = useState('');
  const [giftRecipient, setGiftRecipient] = useState('');
  const [memories, setMemories] = useState<Memory[]>([]);
  const [newMemory, setNewMemory] = useState({
    type: 'text' as const,
    title: '',
    content: ''
  });

  const addMemory = () => {
    if (newMemory.title && newMemory.content) {
      const memory: Memory = {
        id: Date.now().toString(),
        ...newMemory
      };
      setMemories([...memories, memory]);
      setNewMemory({ type: 'text', title: '', content: '' });
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (title && description && openDate && memories.length > 0) {
      const capsule: Capsule = {
        id: '',
        title,
        description,
        memories,
        openDate,
        isOpened: false,
        createdAt: new Date().toISOString(),
        giftRecipient: giftRecipient || undefined
      };
      onCreateCapsule(capsule);
      setTitle('');
      setDescription('');
      setOpenDate('');
      setGiftRecipient('');
      setMemories([]);
    }
  };

  const getMemoryIcon = (type: string) => {
    switch (type) {
      case 'text': return <FileText className="w-4 h-4" />;
      case 'photo': return <Camera className="w-4 h-4" />;
      case 'audio': return <Music className="w-4 h-4" />;
      default: return <FileText className="w-4 h-4" />;
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-lg p-8">
      <h2 className="text-2xl font-bold text-gray-900 mb-6">Create Memory Capsule</h2>
      
      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Capsule Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder="My 2024 Memories"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              <Calendar className="w-4 h-4 inline mr-1" />
              Open Date
            </label>
            <input
              type="date"
              value={openDate}
              onChange={(e) => setOpenDate(e.target.value)}
              className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              min={new Date().toISOString().split('T')[0]}
              required
            />
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Description
          </label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={3}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            placeholder="A collection of memories from this year..."
            required
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            <Gift className="w-4 h-4 inline mr-1" />
            Gift Recipient (Optional)
          </label>
          <input
            type="text"
            value={giftRecipient}
            onChange={(e) => setGiftRecipient(e.target.value)}
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
            placeholder="Future me, my children, my partner..."
          />
        </div>

        <div className="border-t pt-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Add Memories</h3>
          
          <div className="bg-gray-50 rounded-lg p-6 mb-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <select
                value={newMemory.type}
                onChange={(e) => setNewMemory({ ...newMemory, type: e.target.value as any })}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              >
                <option value="text">Text Memory</option>
                <option value="photo">Photo</option>
                <option value="audio">Audio Note</option>
              </select>

              <input
                type="text"
                value={newMemory.title}
                onChange={(e) => setNewMemory({ ...newMemory, title: e.target.value })}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                placeholder="Memory title"
              />

              <button
                type="button"
                onClick={addMemory}
                className="flex items-center justify-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                <Plus className="w-4 h-4" />
                <span>Add</span>
              </button>
            </div>

            <textarea
              value={newMemory.content}
              onChange={(e) => setNewMemory({ ...newMemory, content: e.target.value })}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
              placeholder={
                newMemory.type === 'text' 
                  ? 'Write your memory...' 
                  : newMemory.type === 'photo' 
                  ? 'Paste image URL or describe the photo...' 
                  : 'Describe the audio or paste audio URL...'
              }
            />
          </div>

          {memories.length > 0 && (
            <div className="space-y-3 mb-6">
              <h4 className="font-medium text-gray-900">Added Memories ({memories.length})</h4>
              {memories.map((memory) => (
                <div key={memory.id} className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                  {getMemoryIcon(memory.type)}
                  <div className="flex-1">
                    <div className="font-medium text-gray-900">{memory.title}</div>
                    <div className="text-sm text-gray-600 truncate">{memory.content}</div>
                  </div>
                  <span className="text-xs text-purple-600 bg-purple-100 px-2 py-1 rounded">
                    {memory.type}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <button
          type="submit"
          disabled={!title || !description || !openDate || memories.length === 0}
          className="w-full bg-purple-600 text-white py-3 rounded-lg font-semibold hover:bg-purple-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors"
        >
          Create Memory Capsule
        </button>
      </form>
    </div>
  );
};

export default CreateCapsule;
 